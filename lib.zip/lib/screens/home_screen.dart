import 'dart:convert';  // ใช้ jsonDecode สำหรับแปลงข้อมูล JSON
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../widgets/create_room_dialog.dart';  // เพิ่มการนำเข้า
import 'profile_page.dart';
import 'package:team_up/configserver/cf.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'room_list_screen.dart'; // นำเข้า RoomListScreen

class HomeScreen extends StatefulWidget {
  final String token;

  const HomeScreen({Key? key, required this.token}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  List<Map<String, dynamic>> _rooms = [];
  List<Map<String, dynamic>> _joinedRooms = []; // ประกาศตัวแปร _joinedRooms เพื่อเก็บข้อมูลห้องที่ผู้ใช้เข้าร่วม
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchRoomsFromDatabase();
    _fetchJoinedRoomsFromDatabase(); // ดึงข้อมูลห้องที่เข้าร่วมจากฐานข้อมูล
  }

  // ฟังก์ชันดึงข้อมูลห้องทั้งหมดจากฐานข้อมูล
  Future<void> _fetchRoomsFromDatabase() async {
    final url = Uri.parse('$baseUrl/rooms'); // ใช้ baseUrl จาก configserver
    try {
      final response = await http.get(
        url,
        headers: {'Authorization': 'Bearer ${widget.token}'}, // เพิ่ม Header Authorization
      );
      if (response.statusCode == 200) {
        final List<dynamic> fetchedRooms = jsonDecode(response.body);
        setState(() {
          _rooms = fetchedRooms.cast<Map<String, dynamic>>(); // อัปเดตข้อมูลห้องที่สร้าง
          _isLoading = false;
        });
      } else {
        print('Failed to load rooms: ${response.statusCode}');
        setState(() {
          _isLoading = false;
        });
      }
    } catch (error) {
      print('Error fetching rooms: $error');
      setState(() {
        _isLoading = false;
      });
    }
  }

  // ฟังก์ชันเพิ่มผู้ใช้เข้าร่วมห้อง
  Future<void> joinRoom(String roomId) async {
    // ตรวจสอบว่าผู้ใช้ได้เข้าร่วมห้องนี้แล้วหรือยัง
    if (_joinedRooms.any((room) => room['_id'] == roomId)) {
      // ถ้าเข้าร่วมแล้วจะไม่สามารถกด Join ได้
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('คุณได้เข้าร่วมห้องนี้แล้ว')),
      );
      return;
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      final String? userId = prefs.getString('userId');
      final String? token = prefs.getString('jwt_token');

      if (userId == null || token == null) {
        print('Error: User ID or Token is missing.');
        return;
      }

      final response = await http.post(
        Uri.parse('$baseUrl/rooms/join/$roomId'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'userId': userId}),
      );

      if (response.statusCode == 200) {
        print('Successfully joined the room: ${response.body}');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Joined the room successfully!')),
        );

        // อัปเดตข้อมูลห้องที่จอย
        await _fetchJoinedRoomsFromDatabase();
      } else {
        print('Failed to join room: ${response.body}');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to join room: ${response.body}')),
        );
      }
    } catch (e) {
      print('Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error joining the room.')),
      );
    }
  }

  // ฟังก์ชันแสดงห้องที่ผู้ใช้เข้าร่วม
  Future<void> _fetchJoinedRoomsFromDatabase() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getString('userId');
    final token = prefs.getString('jwt_token');

    if (userId == null || token == null) {
      print('Error: User ID or Token is missing.');
      return;
    }

    try {
      final url = Uri.parse('$baseUrl/rooms/joined/$userId');
      final response = await http.get(
        url,
        headers: {'Authorization': 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> fetchedRooms = jsonDecode(response.body);
        setState(() {
          _joinedRooms = fetchedRooms.cast<Map<String, dynamic>>(); // อัปเดตข้อมูลห้องที่ผู้ใช้เข้าร่วม
        });
      } else {
        print('Failed to fetch joined rooms: ${response.body}');
      }
    } catch (error) {
      print('Error fetching joined rooms: $error');
    }
  }

  // ฟังก์ชันเปลี่ยนหน้าเมื่อคลิกที่เมนู
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      if (_selectedIndex == 1) {
        _fetchJoinedRoomsFromDatabase(); // อัปเดตข้อมูลห้องที่จอยเมื่อเปลี่ยนไปหน้า Schedule
      }
    });
  }

  // ฟังก์ชันการแสดงหน้า Home
  Widget _buildHomePage() {
    return ListView(
      padding: const EdgeInsets.all(16.0),
      children: [
        if (_isLoading)
          const Center(child: CircularProgressIndicator())
        else if (_rooms.isEmpty)
          const Center(
            child: Text(
              'ยังไม่มีห้องที่สร้าง',
              style: TextStyle(color: Colors.grey),
            ),
          )
        else
          ..._rooms.map((room) {
            // ตรวจสอบสถานะห้องและปรับสีพื้นหลัง
            Color statusColor = room['currentParticipants'] >= room['maxParticipants']
                ? Colors.red // ห้องเต็ม
                : Colors.green; // ห้องยังว่าง
            return Card(
              child: Column(
                children: [
                  if (room['imagePath'] != null && room['imagePath'].isNotEmpty)
                    Image.network(
                      room['imagePath'], // ใช้ URL ของรูปภาพจากฐานข้อมูล
                      height: 200,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return const Icon(Icons.broken_image, size: 100, color: Colors.grey);
                      },
                    ),
                  ListTile(
                    title: Text(room['sportName']),
                    subtitle: Text(
                      'สนาม: ${room['fieldName']}\n'
                          'เวลา: ${room['time']}\n'
                          'ราคา: ${room['pricePerPerson']} บาท/คน\n'
                          'จำนวน: ${room['maxParticipants']} คน\n'
                          'ผู้เข้าร่วม: ${room['currentParticipants']} คน',
                    ),
                    trailing: Container(
                      padding: const EdgeInsets.all(8.0),
                      color: statusColor, // ใช้สีสถานะห้อง
                      child: Text(
                        '${room['currentParticipants']}/${room['maxParticipants']}',
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  Stack(
                    children: [
                      Positioned(
                        left: 10,
                        bottom: 10,
                        child: ElevatedButton(
                          onPressed: () => joinRoom(room['_id']), // ตรวจสอบการเข้าร่วมห้องก่อน
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.orange, // ปรับสีพื้นหลังของปุ่ม
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15), // เพิ่มมุมมน
                            ),
                            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 20), // ลดขนาดปุ่ม
                          ),
                          child: Text(
                            'Join',
                            style: TextStyle(fontSize: 14, color: Colors.white),
                          ),
                        ),
                      ),
                      Positioned(
                        right: 10,
                        bottom: 10,
                        child: Container(
                          padding: const EdgeInsets.all(8.0),
                          color: Colors.black.withOpacity(0.5), // ใส่พื้นหลังโปร่งใส
                          child: Text(
                            '${room['currentParticipants']}/${room['maxParticipants']}',
                            style: const TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          }).toList(),
      ],
    );
  }
  void _showCreateRoomDialog(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return const CreateRoomDialog(); // ให้ทำงานเมื่อมีการคลิกปุ่ม
      },
    );

    if (result == true) {
      _fetchRoomsFromDatabase(); // รีเฟรชข้อมูลหลังจากสร้างห้องใหม่
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildHomePage(),
      RoomListScreen(token: widget.token), // แทนที่ _buildSchedulePage ด้วย RoomListScreen
      ProfilePage(token: widget.token),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          _selectedIndex == 0 ? 'Home' : _selectedIndex == 1 ? 'Schedule' : 'Profile',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.orange,
        automaticallyImplyLeading: false,
      ),
      body: pages[_selectedIndex],
      floatingActionButton: _selectedIndex == 0
          ? FloatingActionButton.extended(
        onPressed: () {
          _showCreateRoomDialog(context);
        },
        label: const Text('สร้างเลย'),
        backgroundColor: Colors.orange,
      )
          : null,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.schedule), label: 'Schedule'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
