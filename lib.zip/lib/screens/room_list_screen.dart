import 'dart:convert'; // ใช้ jsonDecode สำหรับแปลงข้อมูล JSON
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:team_up/configserver/cf.dart'; // ตรวจสอบว่า baseUrl ถูกต้องหรือไม่

class RoomListScreen extends StatefulWidget {
  final String token;

  const RoomListScreen({Key? key, required this.token}) : super(key: key);

  @override
  _RoomListScreenState createState() => _RoomListScreenState();
}

class _RoomListScreenState extends State<RoomListScreen> {
  List<Map<String, dynamic>> _joinedRooms = [];
  bool _isLoading = true;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _fetchJoinedRoomsFromDatabase();
  }

  // ฟังก์ชันดึงข้อมูลห้องที่ผู้ใช้เข้าร่วม
  Future<void> _fetchJoinedRoomsFromDatabase() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getString('userId');
    final token = prefs.getString('jwt_token');

    if (userId == null || token == null) {
      print('Error: User ID or Token is missing.');
      setState(() {
        _isLoading = false;
        _errorMessage = 'User ID or Token is missing';
      });
      return;
    }

    try {
      final url = Uri.parse('$baseUrl/rooms/joined/$userId');
      final response = await http.get(
        url,
        headers: {'Authorization': 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> fetchedRooms = jsonDecode(response.body);
        setState(() {
          _joinedRooms = fetchedRooms.cast<Map<String, dynamic>>(); // อัปเดตข้อมูลห้องที่ผู้ใช้เข้าร่วม
          _isLoading = false;  // ปิดการหมุน
        });
      } else {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Failed to fetch rooms: ${response.statusCode}';
        });
        print('Failed to fetch joined rooms: ${response.body}');
      }
    } catch (error) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Error fetching rooms: $error';
      });
      print('Error fetching rooms: $error');
    }
  }

  // ฟังก์ชันยกเลิกการเข้าร่วมห้อง
  Future<void> _cancelRoom(Map<String, dynamic> room) async {
    final url = Uri.parse('$baseUrl/rooms/leave/${room["_id"]}');
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? userId = prefs.getString('userId');
      final String? token = prefs.getString('jwt_token');

      if (userId == null || token == null) {
        print('Error: User ID or Token is missing.');
        return;
      }

      final response = await http.delete(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'userId': userId}), // ส่ง userId ไปใน body
      );

      if (response.statusCode == 200) {
        setState(() {
          _joinedRooms.remove(room); // ลบห้องที่ออกจากการเข้าร่วม
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ยกเลิกการเข้าร่วมห้อง ${room["sportName"]} เรียบร้อย!')),
        );
      } else {
        print('Failed to cancel room: ${response.body}');
      }
    } catch (error) {
      print('Error canceling room: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return _isLoading
        ? const Center(child: CircularProgressIndicator())  // แสดงการหมุนรอเมื่อข้อมูลกำลังโหลด
        : _errorMessage.isNotEmpty
        ? Center(child: Text(_errorMessage))  // แสดงข้อผิดพลาดหากการดึงข้อมูลล้มเหลว
        : ListView(
      padding: const EdgeInsets.all(16.0),
      children: [
        if (_joinedRooms.isEmpty)
          const Center(
            child: Text(
              'ยังไม่มีห้องที่เข้าร่วม',
              style: TextStyle(color: Colors.grey),
            ),
          )
        else
          ..._joinedRooms.map((room) {
            return Card(
              child: ListTile(
                title: Text(room['sportName']),
                subtitle: Text(
                  'สนาม: ${room['fieldName']}\n'
                      'เวลา: ${room['time']}\n'
                      'ราคา: ${room['pricePerPerson']} บาท/คน\n'
                      'จำนวน: ${room['maxParticipants']} คน',
                ),
                trailing: ElevatedButton(
                  onPressed: () => _cancelRoom(room),  // เมื่อกดปุ่ม Cancel จะยกเลิกการเข้าร่วมห้อง
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,  // เปลี่ยนสีของปุ่มเป็นสีแดง
                  ),
                  child: const Text('Cancel'),
                ),
              ),
            );
          }).toList(),
      ],
    );
  }
}
