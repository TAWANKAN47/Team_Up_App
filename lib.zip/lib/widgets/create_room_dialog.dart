import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:team_up/configserver/cf.dart'; // นำเข้า baseUrl
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'select_location_screen.dart';

class CreateRoomDialog extends StatefulWidget {
  const CreateRoomDialog({Key? key}) : super(key: key);

  @override
  _CreateRoomDialogState createState() => _CreateRoomDialogState();
}

class _CreateRoomDialogState extends State<CreateRoomDialog> {
  final TextEditingController _sportNameController = TextEditingController();
  final TextEditingController _fieldNameController = TextEditingController();
  final TextEditingController _totalPriceController = TextEditingController();
  final TextEditingController _timeController = TextEditingController();

  int _maxParticipants = 2;
  LatLng? _selectedLocation;
  String? _locationText;
  File? _selectedImage;
  String? _selectedProvince;

  bool _isLoading = false;

  final List<String> provinces = [
    'กรุงเทพมหานคร', 'เชียงใหม่', 'ภูเก็ต', 'ขอนแก่น', 'ชลบุรี', 'สงขลา', 'นครราชสีมา'
  ];

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      title: const Text(
        'สร้างห้องใหม่',
        style: TextStyle(color: Colors.orange),
      ),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ชื่อกีฬา
            TextField(
              controller: _sportNameController,
              decoration: const InputDecoration(
                labelText: 'ชื่อกีฬา',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            // ชื่อสนาม
            TextField(
              controller: _fieldNameController,
              decoration: const InputDecoration(
                labelText: 'ชื่อสนาม',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            // เวลาเล่น
            TextField(
              controller: _timeController,
              decoration: const InputDecoration(
                labelText: 'เวลาเล่น (เช่น 2 ชั่วโมง)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            // ราคารวมทั้งหมด
            TextField(
              controller: _totalPriceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'ราคารวมทั้งหมด (บาท)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            // จังหวัด
            DropdownButtonFormField<String>(
              value: _selectedProvince,
              hint: const Text('เลือกจังหวัด'),
              items: provinces.map((province) {
                return DropdownMenuItem(
                  value: province,
                  child: Text(province),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedProvince = value;
                });
              },
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            // จำนวนคนสูงสุด
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('จำนวนผู้เข้าร่วมสูงสุด'),
                DropdownButton<int>(
                  value: _maxParticipants,
                  items: List.generate(
                    39,
                        (index) => DropdownMenuItem(
                      value: index + 2,
                      child: Text('${index + 2}'),
                    ),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _maxParticipants = value!;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 10),
            // ปักหมุด Location
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Location'),
                TextButton(
                  onPressed: _pickLocation,
                  child: Text(
                    _locationText ?? 'ปักหมุด',
                    style: const TextStyle(color: Colors.orange),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            // แนบรูปภาพ
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('แนบรูปภาพ'),
                TextButton(
                  onPressed: _pickImage,
                  child: const Text('เลือกรูปภาพ',
                      style: TextStyle(color: Colors.orange)),
                ),
              ],
            ),
            if (_selectedImage != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Image.file(
                  _selectedImage!,
                  height: 150,
                  fit: BoxFit.cover,
                ),
              ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text('ยกเลิก'),
        ),
        ElevatedButton(
          onPressed: _isLoading ? null : _createRoom,
          child: _isLoading
              ? const CircularProgressIndicator(color: Colors.white)
              : const Text('สร้าง'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.orange,
          ),
        ),
      ],
    );
  }

  Future<void> _pickLocation() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const SelectLocationScreen(),
      ),
    );

    if (result != null) {
      setState(() {
        _selectedLocation = result;
        _locationText =
        'Lat: ${_selectedLocation!.latitude.toStringAsFixed(4)}, Lng: ${_selectedLocation!.longitude.toStringAsFixed(4)}';
      });
    }
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  Future<String?> _uploadImage(File image) async {
    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/upload'),
      );
      request.files.add(await http.MultipartFile.fromPath('image', image.path));
      final response = await request.send();
      if (response.statusCode == 200) {
        final responseBody = await response.stream.bytesToString();
        return jsonDecode(responseBody)['url'];
      }
    } catch (e) {
      print('Error uploading image: $e');
    }
    return null;
  }

  Future<void> _createRoom() async {
    final String sportName = _sportNameController.text.trim();
    final String fieldName = _fieldNameController.text.trim();
    final String time = _timeController.text.trim();
    final String totalPriceText = _totalPriceController.text.trim();

    if (sportName.isEmpty ||
        fieldName.isEmpty ||
        time.isEmpty ||
        totalPriceText.isEmpty ||
        _selectedProvince == null ||
        _selectedLocation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('กรุณากรอกข้อมูลให้ครบถ้วน')),
      );
      return;
    }

    final double totalPrice = double.tryParse(totalPriceText) ?? 0.0;
    final double pricePerPerson = totalPrice / _maxParticipants;

    setState(() {
      _isLoading = true;
    });

    try {
      String? imageUrl;

      if (_selectedImage != null) {
        imageUrl = await _uploadImage(_selectedImage!);
        if (imageUrl == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('ไม่สามารถอัปโหลดรูปภาพได้')),
          );
          return;
        }
      }

      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final String? token = prefs.getString('jwt_token');
      final String? userId = prefs.getString('userId'); // ดึง userId (_id)

      if (token == null || userId == null) {
        print('Token: $token, User ID: $userId');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ไม่พบ Token หรือข้อมูลผู้ใช้')),
        );
        return;
      }

      final roomData = {
        'sportName': sportName,
        'fieldName': fieldName,
        'time': time,
        'totalPrice': totalPrice,
        'pricePerPerson': pricePerPerson,
        'maxParticipants': _maxParticipants,
        'province': _selectedProvince,
        'location': _locationText,
        'imagePath': imageUrl ?? 'default_image_url',
        'ownerId': userId, // ส่ง _id ของผู้ใช้แทน ownerId
      };

      print('Room Data: $roomData');

      final response = await http.post(
        Uri.parse('$baseUrl/rooms'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode(roomData),
      );

      if (response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('สร้างห้องสำเร็จ!')),
        );
        Navigator.pop(context, true);
      } else {
        print('Response: ${response.body}');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('เกิดข้อผิดพลาด: ${response.body}')),
        );
      }
    } catch (error) {
      print('Error: $error');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('เกิดข้อผิดพลาด: $error')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
}
